/* ======================================================================== */
/*
 * Copyright (c) 2015, E2ForLife.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the E2ForLife.com nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL E2FORLIFE.COM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* ======================================================================== */

#include <cytypes.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
	
#include "CLI.h"
#include "COMIO.h"

#include "FreeRTOS.h"
#include "FreeRTOS_task.h"
#include "FreeRTOS_queue.h"
	
/* ------------------------------------------------------------------------ */
	
CLI_CLI_COMMAND CLI_CommandTable[ 25+1 ];

/* ------------------------------------------------------------------------ */

int CLI_CLIrefresh;
uint8 CLI_CLIinitVar;
uint8 CLI_CLIquiet;

/* ------------------------------------------------------------------------ */
void CLI_Start( void )
{
	CLI_CLIquiet = 0;
	CLI_CLIrefresh = 1;
	CLI_CLIinitVar = 1;
	
	/*
	 * Register commands for help and clear
	 */
	CLI_RegisterCommand(CLI_CliHelp,"help","Display command table descriptions");
	CLI_RegisterCommand(CLI_CliClearScreen,"cls","Clear the screen");
	
	#if (configUSE_TRACE_FACILITY != 0)
	CLI_RegisterCommand(CLI_TaskList,"taskmgr","Display task information");
	CLI_RegisterCommand(CLI_KillTask,"kill","Force delete a task.");	
	#endif
	
	xTaskCreate( CLI_vCliTask, "Cli Task", 600, (void*)&CLI_CommandTable[0], 3, NULL);
}
/* ------------------------------------------------------------------------ */
void CLI_SystemMsg(const char *str, uint8 level)
{
	if (CLI_CLIquiet != 0) return;
	
	switch(level) {
		case CLI_NOTE:
			COMIO_PrintString("\r\n{c4}[{c10}NOTE{c4}]{c7}:");
			COMIO_PrintString(str);
			break;
		case CLI_WARN:
			COMIO_PrintString("\r\n{c4}[{c11}WARNING{c4}]{c7}: ");
			COMIO_PrintString(str);
			break;
		case CLI_ERROR:
			COMIO_PrintString("\r\n{c4}[{c9}ERROR{c4}]{c7}: ");
			COMIO_PrintString(str);
			break;
		case CLI_FATAL:
			COMIO_PrintString("\r\n{c4}[{c9}FATAL{c4}]{c7}: {c9}");
			COMIO_PrintString(str);
			break;
		default:
			COMIO_PrintString("\r\n{c4}[{c15}????{c4}]{c7}: ");
			COMIO_PrintString(str);
			break;
	}
}
/* ------------------------------------------------------------------------ */
uint8 CLI_AreYouSure( char* msg, uint8 defVal )
{
	const char *values[] = {"No", "Yes"};
	char out[31];
	uint8 result;
	
	result = 255;
	
	COMIO_PrintString(msg);
	if (defVal != 0) {
		sprintf(out," {c6}%s{c4}/{c14}%s{c7} : ", values[0], values[1] );
	}
	else {
		sprintf(out," {c14}%s{c4}/{c6}%s{c7} : ", values[0], values[1] );
	}	
	COMIO_PrintString(out);
	do {
		out[0] = COMIO_GetChar();
	
		if (toupper((int)out[0]) == 'Y') {
			result = 1;
		}
		else if (toupper((int)out[0]) == 'N') {
			result = 0;
		}
		else if ((out[0] == '\r') || (out[0] == '\n')) {
			result = defVal;
		}
	} while (result > 1);
	
	return result;
}
/* ------------------------------------------------------------------------ */
uint32 CLI_GetValueParam(char *arg)
{
	uint32 value;
	
	value = 0;
	
	if (strncmp(arg,"0x",2) == 0) {
		value = CLI_convHex(&arg[2]);
	}
	else if (isdigit((int)arg[0])) {
		sscanf(arg,"%lu",&value);
	}
	
	return value;
}
/* ------------------------------------------------------------------------ */
uint32 CLI_convHex(char *hex)
{
	uint32 value;
	int idx;
	int digit;
	
	value = 0;
	for(idx=0;(hex[idx]!=0)&&(idx<8)&&(isxdigit((int)(hex[idx])));++idx) {
		value <<= 4;
		digit = toupper((int)hex[idx]);
		if (digit >= 'A') {
			value += 10 + (digit - 'A');
		}
		else {
			value += (digit - '0');
		}
	}
	
	return value;
}
/* ------------------------------------------------------------------------ */
cystatus CLI_CliHelp( int argc, char **argv )
{
	int idx;
	char bfr[51];
	
	COMIO_PrintString("{row1;col1;mv;cls}");
	
	idx = 0;
	while ( strlen(CLI_CommandTable[idx].name) != 0) {
		if ( strlen(CLI_CommandTable[idx].desc) > 0 ) {
			sprintf(bfr,"\r\n{c4}[{c15}%10s{c4}]{c7} : ",CLI_CommandTable[idx].name);
			COMIO_PrintString(bfr);
			sprintf(bfr,"{c%d}",((idx&0x01)?10:2));
			COMIO_PrintString(bfr);
			COMIO_PrintString(CLI_CommandTable[idx].desc);
		}
		++idx;
	}
	COMIO_PrintString("\r\n\n");
	return CYRET_SUCCESS;
}
/* ------------------------------------------------------------------------ */
cystatus CLI_CliClearScreen( int argc, char **argv )
{
	argc = argc;
	argv = argv;
	
	COMIO_PrintString("{row;col;mv;cls}");
	return CYRET_SUCCESS;
}
/* ------------------------------------------------------------------------ */
void CLI_CliShowPrompt( char *lineBuffer )
{
	if (CLI_CLIquiet != 0) return;
	
	COMIO_PrintString("\r\n");
	COMIO_PrintString("\r\n{c6}Welcome to the E2ForLife Command Shell\r\n{c2}Enter{c10} help{c2} for a list of commands.");
	COMIO_PrintString("\r\n{c4}[{c15}CLI{c4}]{c7}: {c14;b4}                                                   {left51} ");
	COMIO_PrintString( lineBuffer);
}
/* ------------------------------------------------------------------------ */
cystatus CLI_RegisterCommand( CLI_CLIfunc fn, char *cmd, char *description)
{
	int idx;
	
	cystatus result;
	
	result = CYRET_UNKNOWN;
	
	if ( fn != NULL )
	{
		/* look for the first available command slot in the table */
		for( idx = 0;(idx<25)&&(strlen( CLI_CommandTable[idx].name) >0); ++idx);
		if (idx <25) {
			/*
			 * There was a slot available in the command table, so allocate the
			 * position, and store the command information in to the table.
			 */
			CLI_CommandTable[idx].fn = fn;
			memcpy((void*)&CLI_CommandTable[idx].name[0], cmd, strlen(cmd) );
			memcpy((void*)&CLI_CommandTable[idx].desc[0], description, strlen(description));
			result = CYRET_SUCCESS;
		}
		
	}
	else {
		result = CYRET_BAD_PARAM;
	}
	
	return result;
}

/* ------------------------------------------------------------------------ */
int CLI_CliGetArguments( char *buffer, int *argc, char **argv )
{
	int idx;
	cystatus result;
	
	result = CYRET_STARTED;
	idx = 0;
	*argc = 0;
	while ( (buffer[idx] != 0) && (result == CYRET_STARTED) ) {
		/*
		 * drop leading whitespace, and set all spaces to NULL to
		 * prevent later confusion.
		 */
		while ( (buffer[idx] != 0) && isspace((int)buffer[idx]) ) {
			buffer[idx] = 0;
			++idx;
		}
		/*
		 * now, we know that the index is pointing to a non-space character,
		 * so process the character based upon it's state.
		 */
		if (buffer[idx] == ';') {
			/* 
			 * The end of a command can be the end of the buffer, or, a
			 * semicolon can be used for the creation of compound
			 * statements.
			 * A compound statement seperator was detected, so, clear it to
			 * form a terminator for the last argument, and then, set the
			 * result to finished to let the processor know that the arguments
			 * of the current command are now fully split.
			 */
			buffer[idx++] = 0;
			result = CYRET_FINISHED;
		}
		/*
		 * Otherwise, store the character location, and move the index pointer
		 * to the next break in the input, or the end of the buffer
		 */
		else {
			argv[*argc] = &buffer[idx];
			*argc = *argc + 1;
			while ( (!isspace((int)buffer[idx])) && (buffer[idx] != 0) && (buffer[idx] != ';') ) {
				++idx;
			}
			/*
			 * Set a terminator, if a space was detected, and update the index
			 * pointer to the next value.
			 */
			if ( isspace((int)buffer[idx]) ) {
				buffer[idx++] = 0;
			}
		}
	}
	
	return idx;
}
/* ------------------------------------------------------------------------ */
/**
 * \brief Process a token from the line buffer as a read or write operation
 * \param *buffer pointer to the buffer (with the read operator removed)
 * \param read identifier for read operation or write operations
 *
 * process token will pull the next token (has to be a label) from the input
 * buffer, and process the line to completion.  If there is a syntax error
 * the buffer is dumped and the user is notified. otherwise, the processor
 * function is called.
 */
cystatus CLI_CliProcessCommand(const CLI_CLI_COMMAND *tbl, int argc, char **argv)
{
	int idx;
	CLI_CLIfunc fn;
	
	static char outBuffer[128];
	
	cystatus result;
	
	if (tbl == NULL) {
		CLI_SystemMsg("Invalid command table",CLI_FATAL);
		return CYRET_UNKNOWN;
	}
	
	result = CYRET_UNKNOWN;
	fn = NULL;
	if (argc > 0) {
		/* look for the processed command */
		idx = 0;
		while ( ( strlen(tbl[idx].name ) > 0) && (idx < 25) ) {
			if ( strcmp(tbl[idx].name, argv[0]) == 0 ) {
				fn = tbl[idx].fn;
				if (fn != NULL) {
					result = fn(argc,argv);
				}
				else {
					result = CYRET_INVALID_OBJECT;
					sprintf(outBuffer,"\"%s\" has not yet been implemented.",argv[0]);
					CLI_SystemMsg(outBuffer,CLI_WARN);
				}
			}
			++idx;
		}
		
		if (result == CYRET_UNKNOWN) {
			sprintf(outBuffer,"Unknown Command \"%s\"",argv[0]);
			CLI_SystemMsg(outBuffer, CLI_ERROR);
		}
	}
	return result;
}
/* ======================================================================== */
	
void CLI_vCliTask( void *pvParameters )
{
	/* Buffer to hold received user input on the line */
	static char lineBuffer[51];
	
 	CLI_CLI_COMMAND *CommandTable;
	int idx;
	char *argv[25];
	int argc;
	
	
	/*
	 * Grab the adadress of the command table from the OS parameters
	 * passed to the task, and assign them to the local data used in the CLI
	 */
	CommandTable = (CLI_CLI_COMMAND*) pvParameters;

	/*
	 * User CLI initialization code for Performing any operations to setup
	 * special hardware or other item prior to the connection validation.
	 */
	/* `#START USER_CLI_INITIALIZATION_BEFORE_CONNECT` */

	/* `#END` */

	/*
	 * CLI Initialization:
	 * Wait for user input to confirm that the CLI has connected with a
	 * terminal.. essentially, since the USB port is open and connected
	 * the second it attaches, we must wait for user input to validate the
	 * connection, and make sure that the prompts are visible.
	 */
	COMIO_GetChar();
	lineBuffer[0] = 0;
	/*
	 * The connection has been validated, this merge region allows the
	 * definition of functions that are performed once the connection
	 * is connected and valid. For Example, this might be a great place to
	 * add a welcome string, logon, or some other thing such as this.
	 */
	/* `#START USER_CLI_INITIALIZATION_AFTER_CONNECT` */

	/* `#END` */
	
	for(;;) {
		/*
		 * Wait for user input.
		 */
		CLI_CliShowPrompt(lineBuffer);
		
		/* Read the input line from the user with blocking functions */
		COMIO_GenericGetString( lineBuffer, CLI_CLIquiet );
		
		/* Set the color to neutral to avoid screen junk when executing commands */
		if (CLI_CLIquiet == 0) COMIO_PrintString("{c7;b0}");
		
		/*
		 * Strip arguments from the line buffer, and handle compound
		 * statements by looping through the input buffer until the NULL
		 * is encountered.
		 */
		idx = 0;
		while ( lineBuffer[ idx ] != 0) {
			idx += CLI_CliGetArguments(&lineBuffer[idx],&argc,argv);
			if (argc > 0) {
				CLI_CliProcessCommand(CommandTable,argc,argv);
			}
		}
		
		/* Erase the contents of the line buffer at the end of the command */
		memset((void*)&lineBuffer[0],0,idx);
	}
}
/* ------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------ */
/* [] END OF FILE */
