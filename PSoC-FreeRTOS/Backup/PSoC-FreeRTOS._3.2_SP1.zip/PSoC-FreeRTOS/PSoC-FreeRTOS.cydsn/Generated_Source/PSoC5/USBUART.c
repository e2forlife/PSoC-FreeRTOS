/* ======================================================================== */
/*
 * Copyright (c) 2015, E2ForLife.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the E2ForLife.com nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL E2FORLIFE.COM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* ======================================================================== */
#include <cytypes.h>
#include <cylib.h>
#include <stdio.h>

#include "USBUART.h"
#include "USBUART_USBUART.h"
#include "USBUART_USBUART_cdc.h"

#include "FreeRTOS.h"
#include "FreeRTOS_task.h"
#include "FreeRTOS_queue.h"
#include "FreeRTOS_semphr.h"

/* ======================================================================== */

xQueueHandle USBUART_RxQ;
xQueueHandle USBUART_TxQ;
xSemaphoreHandle USBUART_Mutex;

uint8 USBUART_initVar;

/* ======================================================================== */
void USBUART_Start( void )
{
	if (USBUART_initVar != 1) {
		USBUART_Init();
	}
	
	/* Check for enumeration after initialization */
	USBUART_Enable();
}
/* ------------------------------------------------------------------------ */
void USBUART_Init( void )
{
	/*  Initialize the USB COM port */
	
	if (USBUART_USBUART_initVar == 0) {
    	/* Start USBFS Operation with 3V operation */
		#if (CYDEV_VDDIO1_MV < 5000)
    		USBUART_USBUART_Start(0u, USBUART_USBUART_3V_OPERATION);
		#else
			USBUART_USBUART_Start(0u, USBUART_USBUART_5V_OPERATION);
		#endif
	}
	
	/* Initialize and create the semaphore */
	USBUART_Mutex = xSemaphoreCreateMutex();
	
	/* Initialize USB Buffers */
	USBUART_TxQ = xQueueCreate( 512, 1 );
	USBUART_RxQ = xQueueCreate( 512, 1 );
	
	xTaskCreate( USBUART_Task,"USBUART Task", 400, NULL, 3, NULL);
	
	USBUART_initVar = 1;
}
/* ------------------------------------------------------------------------ */
void USBUART_Enable( void )
{
	if (USBUART_initVar != 0) {
		/*
		 * COMIO was initialized, and now is bing enabled for use.
		 * Enter user extension enables within the merge region below.
		 */
		/* `#START COMIO_ENABLE` */

		/* `#END` */
	}
}
/* ======================================================================== */
void USBUART_Task( void *pvParameters )
{
    uint16 count;
    uint8 buffer[USBUART_BUFFER_LEN];
	uint16 idx;
	
	for (;;) {
		/* Handle enumeration of USB port */
    	if(USBUART_USBUART_IsConfigurationChanged() != 0u) /* Host could send double SET_INTERFACE request */
    	{
        	if(USBUART_USBUART_GetConfiguration() != 0u)   /* Init IN endpoints when device configured */
        	{
            	/* Enumeration is done, enable OUT endpoint for receive data from Host */
            	USBUART_USBUART_CDC_Init();
        	}
    	}
		/*
		 *
		 */
	    if(USBUART_USBUART_GetConfiguration() != 0u)
	    {
			/*
			 * Process received data from the USB, and store it in to the
			 * receiver message Q.
			 */
	        if(USBUART_USBUART_DataIsReady() != 0u)
	        {   
	            count = USBUART_USBUART_GetAll(buffer);
	            if(count != 0u)
	            {
					/* insert data in to Receive FIFO */
					for(idx=0;idx<count;++idx) {
						xQueueSend( USBUART_RxQ, (void*)&buffer[idx],0);
					}
				}
			}
			/*
			 * Send a block of data ack through the USB port to the PC,
			 * by checkig to see if there is data to send, then sending
			 * up to the BUFFER_LEN of data (64 bytes)
			 */
			count = uxQueueMessagesWaiting( USBUART_TxQ );
			count = (count > USBUART_BUFFER_LEN)? USBUART_BUFFER_LEN:count;
			
			/* When component is ready to send more data to the PC */			
            if ( (USBUART_USBUART_CDCIsReady() != 0u) && (count > 0) ) {
				/*
				 * Read the data from the transmit queue and buffer it
				 * locally so that the data can be utilized.
				 */
				for (idx = 0; idx < count; ++idx) {
					xQueueReceive( USBUART_TxQ,&buffer[idx],0);
				}
				/* Send data back to host */
    	        USBUART_USBUART_PutData(buffer, count);
				
				/* If the last sent packet is exactly maximum packet size, 
            	 *  it shall be followed by a zero-length packet to assure the
             	 *  end of segment is properly identified by the terminal.
             	 */
            	if(count == USBUART_BUFFER_LEN){
					/* Wait till component is ready to send more data to the PC */
                	while(USBUART_USBUART_CDCIsReady() == 0u) {
						vTaskDelay( 10 / portTICK_RATE_MS );
					}
                	USBUART_USBUART_PutData(NULL, 0u);         /* Send zero-length packet to PC */
            	} 
			}
		}
		
		vTaskDelay(10/portTICK_PERIOD_MS);
	}
}

/* ======================================================================== */
cystatus USBUART_Read(uint8* value, uint32 length)
{
	uint32 idx;
	cystatus status;
	
	xSemaphoreTake(USBUART_Mutex, portMAX_DELAY);
	{
		status = CYRET_SUCCESS;
		idx = 0;
		while ( (idx<length) && (status == CYRET_SUCCESS) ) {
			if ( xQueueReceive( USBUART_RxQ, (void*)&value[idx], portMAX_DELAY) != pdPASS) {
				status = CYRET_MEMORY;
			}
			++idx;
		}
	}
	xSemaphoreGive( USBUART_Mutex );
	return status;
}
/* ------------------------------------------------------------------------ */
cystatus USBUART_ReadByte( uint8* value )
{
	portBASE_TYPE xStatus;
	
	/* wait for data to become available */
	xStatus = xQueueReceive( USBUART_RxQ, (void*)value, portMAX_DELAY);
	
	return (xStatus == pdPASS)?CYRET_SUCCESS:CYRET_MEMORY;;
}
/* ------------------------------------------------------------------------ */
uint32 USBUART_DataWaiting( void )
{
	return (uint32) uxQueueMessagesWaiting( USBUART_RxQ );
}
/* ------------------------------------------------------------------------ */
void USBUART_UnRead( uint8* value, uint32 len )
{
	uint32 idx;
	portBASE_TYPE xStatus;
	
	xSemaphoreTake(USBUART_Mutex, portMAX_DELAY);
	{
		xStatus = pdPASS;
		idx = 0;
		while ( (idx<len) && (xStatus == pdPASS) ) {
			xStatus = xQueueSendToFront( USBUART_RxQ, &value[idx], 0);
		}
	}
	xSemaphoreGive( USBUART_Mutex );
}	
/* ======================================================================== */
/* ------------------------------------------------------------------------ */
cystatus USBUART_WriteByte( uint8 ch )
{
	
	portBASE_TYPE xStatus;
	
	xStatus = xQueueSend( USBUART_TxQ, (void*)&ch, portMAX_DELAY);
	
	return (xStatus == pdPASS)?CYRET_SUCCESS:CYRET_MEMORY;
}
/* ------------------------------------------------------------------------ */
cystatus USBUART_Write( uint8 *str, uint32 len )
{
	uint32 idx;
	portBASE_TYPE xStatus;
	
	xSemaphoreTake(USBUART_Mutex, portMAX_DELAY);
	{
		xStatus = pdPASS;
		idx = 0;
		for(idx=0; (idx<len) && (xStatus == pdPASS); ++idx ) {
			/* insert character in to the send fifo */
			xStatus = xQueueSend( USBUART_TxQ, (void*)&str[idx], portMAX_DELAY);
		}
	}
	xSemaphoreGive( USBUART_Mutex );
	
	return (xStatus == pdPASS)?CYRET_SUCCESS:CYRET_MEMORY;
}

/* ======================================================================== */
/* [] END OF FILE */
