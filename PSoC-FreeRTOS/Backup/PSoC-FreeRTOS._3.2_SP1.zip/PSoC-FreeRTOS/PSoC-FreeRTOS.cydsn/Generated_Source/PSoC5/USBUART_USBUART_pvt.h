/*******************************************************************************
* File Name: .h
* Version 2.80
*
* Description:
*  This private file provides constants and parameter values for the
*  USBFS Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_USBFS_USBUART_USBUART_pvt_H)
#define CY_USBFS_USBUART_USBUART_pvt_H


/***************************************
*     Private Variables
***************************************/

/* Generated external references for descriptors*/
extern const uint8 CYCODE USBUART_USBUART_DEVICE0_DESCR[18u];
extern const uint8 CYCODE USBUART_USBUART_DEVICE0_CONFIGURATION0_DESCR[67u];
extern const T_USBUART_USBUART_EP_SETTINGS_BLOCK CYCODE USBUART_USBUART_DEVICE0_CONFIGURATION0_EP_SETTINGS_TABLE[3u];
extern const uint8 CYCODE USBUART_USBUART_DEVICE0_CONFIGURATION0_INTERFACE_CLASS[2u];
extern const T_USBUART_USBUART_LUT CYCODE USBUART_USBUART_DEVICE0_CONFIGURATION0_TABLE[5u];
extern const T_USBUART_USBUART_LUT CYCODE USBUART_USBUART_DEVICE0_TABLE[2u];
extern const T_USBUART_USBUART_LUT CYCODE USBUART_USBUART_TABLE[1u];
extern const uint8 CYCODE USBUART_USBUART_SN_STRING_DESCRIPTOR[2];
extern const uint8 CYCODE USBUART_USBUART_STRING_DESCRIPTORS[159u];


extern const uint8 CYCODE USBUART_USBUART_MSOS_DESCRIPTOR[USBUART_USBUART_MSOS_DESCRIPTOR_LENGTH];
extern const uint8 CYCODE USBUART_USBUART_MSOS_CONFIGURATION_DESCR[USBUART_USBUART_MSOS_CONF_DESCR_LENGTH];
#if defined(USBUART_USBUART_ENABLE_IDSN_STRING)
    extern uint8 USBUART_USBUART_idSerialNumberStringDescriptor[USBUART_USBUART_IDSN_DESCR_LENGTH];
#endif /* USBUART_USBUART_ENABLE_IDSN_STRING */

extern volatile uint8 USBUART_USBUART_interfaceNumber;
extern volatile uint8 USBUART_USBUART_interfaceSetting[USBUART_USBUART_MAX_INTERFACES_NUMBER];
extern volatile uint8 USBUART_USBUART_interfaceSetting_last[USBUART_USBUART_MAX_INTERFACES_NUMBER];
extern volatile uint8 USBUART_USBUART_deviceAddress;
extern volatile uint8 USBUART_USBUART_interfaceStatus[USBUART_USBUART_MAX_INTERFACES_NUMBER];
extern const uint8 CYCODE *USBUART_USBUART_interfaceClass;

extern volatile T_USBUART_USBUART_EP_CTL_BLOCK USBUART_USBUART_EP[USBUART_USBUART_MAX_EP];
extern volatile T_USBUART_USBUART_TD USBUART_USBUART_currentTD;

#if(USBUART_USBUART_EP_MM != USBUART_USBUART__EP_MANUAL)
    extern uint8 USBUART_USBUART_DmaChan[USBUART_USBUART_MAX_EP];
    extern uint8 USBUART_USBUART_DmaTd[USBUART_USBUART_MAX_EP];
#endif /*  USBUART_USBUART_EP_MM */
#if((USBUART_USBUART_EP_MM == USBUART_USBUART__EP_DMAAUTO) && (USBUART_USBUART_EP_DMA_AUTO_OPT == 0u))
    extern uint8 USBUART_USBUART_DmaNextTd[USBUART_USBUART_MAX_EP];
    extern const uint8 USBUART_USBUART_epX_TD_TERMOUT_EN[USBUART_USBUART_MAX_EP];
    extern volatile uint16 USBUART_USBUART_inLength[USBUART_USBUART_MAX_EP];
    extern const uint8 *USBUART_USBUART_inDataPointer[USBUART_USBUART_MAX_EP];
    extern volatile uint8 USBUART_USBUART_inBufFull[USBUART_USBUART_MAX_EP];
#endif /*  ((USBUART_USBUART_EP_MM == USBUART_USBUART__EP_DMAAUTO) && (USBUART_USBUART_EP_DMA_AUTO_OPT == 0u)) */

extern volatile uint8 USBUART_USBUART_ep0Toggle;
extern volatile uint8 USBUART_USBUART_lastPacketSize;
extern volatile uint8 USBUART_USBUART_ep0Mode;
extern volatile uint8 USBUART_USBUART_ep0Count;
extern volatile uint16 USBUART_USBUART_transferByteCount;


/***************************************
*     Private Function Prototypes
***************************************/
void  USBUART_USBUART_ReInitComponent(void) ;
void  USBUART_USBUART_HandleSetup(void) ;
void  USBUART_USBUART_HandleIN(void) ;
void  USBUART_USBUART_HandleOUT(void) ;
void  USBUART_USBUART_LoadEP0(void) ;
uint8 USBUART_USBUART_InitControlRead(void) ;
uint8 USBUART_USBUART_InitControlWrite(void) ;
void  USBUART_USBUART_ControlReadDataStage(void) ;
void  USBUART_USBUART_ControlReadStatusStage(void) ;
void  USBUART_USBUART_ControlReadPrematureStatus(void)
                                                ;
uint8 USBUART_USBUART_InitControlWrite(void) ;
uint8 USBUART_USBUART_InitZeroLengthControlTransfer(void)
                                                ;
void  USBUART_USBUART_ControlWriteDataStage(void) ;
void  USBUART_USBUART_ControlWriteStatusStage(void) ;
void  USBUART_USBUART_ControlWritePrematureStatus(void)
                                                ;
uint8 USBUART_USBUART_InitNoDataControlTransfer(void) ;
void  USBUART_USBUART_NoDataControlStatusStage(void) ;
void  USBUART_USBUART_InitializeStatusBlock(void) ;
void  USBUART_USBUART_UpdateStatusBlock(uint8 completionCode) ;
uint8 USBUART_USBUART_DispatchClassRqst(void) ;

void USBUART_USBUART_Config(uint8 clearAltSetting) ;
void USBUART_USBUART_ConfigAltChanged(void) ;
void USBUART_USBUART_ConfigReg(void) ;

const T_USBUART_USBUART_LUT CYCODE *USBUART_USBUART_GetConfigTablePtr(uint8 confIndex)
                                                            ;
const T_USBUART_USBUART_LUT CYCODE *USBUART_USBUART_GetDeviceTablePtr(void)
                                                            ;
const uint8 CYCODE *USBUART_USBUART_GetInterfaceClassTablePtr(void)
                                                    ;
uint8 USBUART_USBUART_ClearEndpointHalt(void) ;
uint8 USBUART_USBUART_SetEndpointHalt(void) ;
uint8 USBUART_USBUART_ValidateAlternateSetting(void) ;

void USBUART_USBUART_SaveConfig(void) ;
void USBUART_USBUART_RestoreConfig(void) ;

#if ((USBUART_USBUART_EP_MM == USBUART_USBUART__EP_DMAAUTO) && (USBUART_USBUART_EP_DMA_AUTO_OPT == 0u))
    void USBUART_USBUART_LoadNextInEP(uint8 epNumber, uint8 mode) ;
#endif /* (USBUART_USBUART_EP_MM == USBUART_USBUART__EP_DMAAUTO) && (USBUART_USBUART_EP_DMA_AUTO_OPT == 0u) */

#if defined(USBUART_USBUART_ENABLE_IDSN_STRING)
    void USBUART_USBUART_ReadDieID(uint8 descr[]) ;
#endif /* USBUART_USBUART_ENABLE_IDSN_STRING */

#if defined(USBUART_USBUART_ENABLE_HID_CLASS)
    uint8 USBUART_USBUART_DispatchHIDClassRqst(void);
#endif /*  USBUART_USBUART_ENABLE_HID_CLASS */
#if defined(USBUART_USBUART_ENABLE_AUDIO_CLASS)
    uint8 USBUART_USBUART_DispatchAUDIOClassRqst(void);
#endif /*  USBUART_USBUART_ENABLE_HID_CLASS */
#if defined(USBUART_USBUART_ENABLE_CDC_CLASS)
    uint8 USBUART_USBUART_DispatchCDCClassRqst(void);
#endif /*  USBUART_USBUART_ENABLE_CDC_CLASS */

CY_ISR_PROTO(USBUART_USBUART_EP_0_ISR);
#if(USBUART_USBUART_EP1_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_1_ISR);
#endif /*  USBUART_USBUART_EP1_ISR_REMOVE */
#if(USBUART_USBUART_EP2_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_2_ISR);
#endif /*  USBUART_USBUART_EP2_ISR_REMOVE */
#if(USBUART_USBUART_EP3_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_3_ISR);
#endif /*  USBUART_USBUART_EP3_ISR_REMOVE */
#if(USBUART_USBUART_EP4_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_4_ISR);
#endif /*  USBUART_USBUART_EP4_ISR_REMOVE */
#if(USBUART_USBUART_EP5_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_5_ISR);
#endif /*  USBUART_USBUART_EP5_ISR_REMOVE */
#if(USBUART_USBUART_EP6_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_6_ISR);
#endif /*  USBUART_USBUART_EP6_ISR_REMOVE */
#if(USBUART_USBUART_EP7_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_7_ISR);
#endif /*  USBUART_USBUART_EP7_ISR_REMOVE */
#if(USBUART_USBUART_EP8_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_EP_8_ISR);
#endif /*  USBUART_USBUART_EP8_ISR_REMOVE */
CY_ISR_PROTO(USBUART_USBUART_BUS_RESET_ISR);
#if(USBUART_USBUART_SOF_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_SOF_ISR);
#endif /*  USBUART_USBUART_SOF_ISR_REMOVE */
#if(USBUART_USBUART_EP_MM != USBUART_USBUART__EP_MANUAL)
    CY_ISR_PROTO(USBUART_USBUART_ARB_ISR);
#endif /*  USBUART_USBUART_EP_MM */
#if(USBUART_USBUART_DP_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBUART_USBUART_DP_ISR);
#endif /*  USBUART_USBUART_DP_ISR_REMOVE */
#if ((USBUART_USBUART_EP_MM == USBUART_USBUART__EP_DMAAUTO) && (USBUART_USBUART_EP_DMA_AUTO_OPT == 0u))
    CY_ISR_PROTO(USBUART_USBUART_EP_DMA_DONE_ISR);
#endif /* (USBUART_USBUART_EP_MM == USBUART_USBUART__EP_DMAAUTO) && (USBUART_USBUART_EP_DMA_AUTO_OPT == 0u) */

/***************************************
* Request Handlers
***************************************/

uint8 USBUART_USBUART_HandleStandardRqst(void) ;
uint8 USBUART_USBUART_DispatchClassRqst(void) ;
uint8 USBUART_USBUART_HandleVendorRqst(void) ;


/***************************************
*    HID Internal references
***************************************/

#if defined(USBUART_USBUART_ENABLE_HID_CLASS)
    void USBUART_USBUART_FindReport(void) ;
    void USBUART_USBUART_FindReportDescriptor(void) ;
    void USBUART_USBUART_FindHidClassDecriptor(void) ;
#endif /* USBUART_USBUART_ENABLE_HID_CLASS */


/***************************************
*    MIDI Internal references
***************************************/

#if defined(USBUART_USBUART_ENABLE_MIDI_STREAMING)
    void USBUART_USBUART_MIDI_IN_EP_Service(void) ;
#endif /* USBUART_USBUART_ENABLE_MIDI_STREAMING */


#endif /* CY_USBFS_USBUART_USBUART_pvt_H */


/* [] END OF FILE */
